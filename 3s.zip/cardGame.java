public abstract class cardGame
{
   //Declare arraylists for hands
   
   
   //Constructor
      //Creates deck
      //Calls dealhand for both players
      
   //????Constructor that accepts! argument for number of players????
 
 
   //player turn abstract
   
   //comp turn abstract
   
   
      
   
   
}


